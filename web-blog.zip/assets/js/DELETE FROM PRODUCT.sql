DELETE FROM PRODUCT
where id = 7
;